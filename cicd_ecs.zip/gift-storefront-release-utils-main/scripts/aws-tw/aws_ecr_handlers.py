import boto3
import csv
from datetime import datetime, timezone
import time
import botocore

### TW SVS

### DEV WGIFT

### PROD GIFT SOLUTIONS


regions = ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'eu-west-1']

tag_keys = ['fiserv::apm', 'fiserv::app', 'fiserv::owner', 'fiserv::group', 'fiserv::description',
            'fiserv::environment', 'fiserv::stage', 'fiserv::artifact', 'fiserv::version']


def get_ecr_images_usage():
    ecr_images = []

    for region in regions:
        print(f"Checking region: {region}")

        # Initialize AWS clients with the provided credentials and region
        ecr_client = boto3.client(
            'ecr',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_session_token=AWS_SESSION_TOKEN,
            region_name=region
        )
        ecs_client = boto3.client(
            'ecs',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_session_token=AWS_SESSION_TOKEN,
            region_name=region
        )
        lambda_client = boto3.client(
            'lambda',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_session_token=AWS_SESSION_TOKEN,
            region_name=region
        )
        codebuild_client = boto3.client(
            'codebuild',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_session_token=AWS_SESSION_TOKEN,
            region_name=region
        )
        eb_client = boto3.client(
            'elasticbeanstalk',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_session_token=AWS_SESSION_TOKEN,
            region_name=region
        )
        ec2_client = boto3.client(
            'ec2',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_session_token=AWS_SESSION_TOKEN,
            region_name=region
        )

        try:
            # Get list of repositories
            repositories = ecr_client.describe_repositories()['repositories']
            print(f"Found {len(repositories)} repositories in region {region}.")

            for repo in repositories:
                repo_name = repo['repositoryName']
                print(f"Checking repository: {repo_name}")

                # Get list of images in the repository
                images = ecr_client.describe_images(repositoryName=repo_name).get('imageDetails', [])
                print(f"Found {len(images)} images in repository {repo_name}.")

                untagged_count = 0
                image_count = len(images)
                tags_in_use = set()
                for image in images:
                    image_tags = image.get('imageTags', [])
                    if not image_tags:
                        untagged_count += 1
                        continue

                    last_updated = image['imagePushedAt']
                    last_used = None
                    usage_details = []
                    safe_to_delete = True
                    tag_values = {key: None for key in tag_keys}

                    print(f"Checking image with tags {image_tags}.")

                    image_uri_base = f"{repo['repositoryUri']}:"

                    # Extract tag values
                    if 'imageTags' in image:
                        for key in tag_keys:
                            tag_values[key] = next(
                                (tag.split('=')[1] for tag in image['imageTags'] if tag.startswith(f"{key}=")), None)

                    # Check ECS clusters for tasks using this image
                    clusters = ecs_client.list_clusters()['clusterArns']
                    for cluster in clusters:
                        services = ecs_client.list_services(cluster=cluster)['serviceArns']
                        for service in services:
                            service_desc = \
                                ecs_client.describe_services(cluster=cluster, services=[service])['services'][0]
                            task_def = service_desc['taskDefinition']
                            task_def_desc = ecs_client.describe_task_definition(taskDefinition=task_def)[
                                'taskDefinition']

                            for container_def in task_def_desc['containerDefinitions']:
                                if container_def['image'].startswith(image_uri_base):
                                    tag = container_def['image'].split(':')[-1]
                                    if tag in image_tags:
                                        if service_desc['status'] == 'ACTIVE':
                                            last_used = datetime.now(timezone.utc)
                                            tags_in_use.add(tag)
                                            usage_details.append(
                                                f"ECS Service: {service_desc['serviceName']} (Revision {task_def_desc['revision']})")
                                            safe_to_delete = False
                                            print(
                                                f"Image {image_tags} is currently running in ECS service {service_desc['serviceName']}.")

                    # Check Lambda functions using this image
                    lambda_functions = lambda_client.list_functions()['Functions']
                    for function in lambda_functions:
                        if 'ImageUri' in function and function['ImageUri'].startswith(image_uri_base):
                            tag = function['ImageUri'].split(':')[-1]
                            if tag in image_tags:
                                if function['State'] == 'Active':
                                    last_used = datetime.now(timezone.utc)
                                    tags_in_use.add(tag)
                                    usage_details.append(f"Lambda Function: {function['FunctionName']}")
                                    safe_to_delete = False
                                    print(
                                        f"Image {image_tags} is currently running in Lambda function {function['FunctionName']}.")

                    # Check CodeBuild projects using this image
                    codebuild_projects = codebuild_client.list_projects()['projects']
                    for project in codebuild_projects:
                        retry_count = 0
                        max_retries = 5
                        while retry_count < max_retries:
                            try:
                                project_desc = codebuild_client.batch_get_projects(names=[project])['projects'][0]
                                break
                            except botocore.exceptions.ClientError as error:
                                if error.response['Error']['Code'] == 'ThrottlingException':
                                    retry_count += 1
                                    wait_time = 2 ** retry_count
                                    print(f"Throttling error, retrying in {wait_time} seconds...")
                                    time.sleep(wait_time)
                                else:
                                    raise

                        if 'image' in project_desc['environment'] and project_desc['environment']['image'].startswith(
                                image_uri_base):
                            tag = project_desc['environment']['image'].split(':')[-1]
                            if tag in image_tags:
                                if project_desc['status'] == 'ACTIVE':
                                    last_used = datetime.now(timezone.utc)
                                    tags_in_use.add(tag)
                                    usage_details.append(f"CodeBuild Project: {project_desc['name']}")
                                    safe_to_delete = False
                                    print(
                                        f"Image {image_tags} is currently running in CodeBuild project {project_desc['name']}.")

                    # Check Elastic Beanstalk environments using this image
                    environments = eb_client.describe_environments()['Environments']
                    for env in environments:
                        env_name = env['EnvironmentName']
                        env_desc = eb_client.describe_environment_resources(EnvironmentName=env_name)
                        for instance in env_desc['EnvironmentResources']['Instances']:
                            instance_id = instance['Id']
                            instance_desc = \
                                ec2_client.describe_instances(InstanceIds=[instance_id])['Reservations'][0][
                                    'Instances'][0]
                            user_data = instance_desc.get('UserData', '')
                            if image_uri_base in user_data:
                                tag = user_data.split(image_uri_base)[1].split()[0]
                                if tag in image_tags:
                                    last_used = datetime.now(timezone.utc)
                                    tags_in_use.add(tag)
                                    usage_details.append(f"Elastic Beanstalk Environment: {env_name}")
                                    safe_to_delete = False
                                    print(
                                        f"Image {image_tags} is currently running in Elastic Beanstalk environment {env_name}.")

                    # Check EC2 instances using this image
                    ec2_instances = ec2_client.describe_instances()['Reservations']
                    for reservation in ec2_instances:
                        for instance in reservation['Instances']:
                            user_data = instance.get('UserData', '')
                            if image_uri_base in user_data:
                                tag = user_data.split(image_uri_base)[1].split()[0]
                                if tag in image_tags:
                                    last_used = datetime.now(timezone.utc)
                                    tags_in_use.add(tag)
                                    usage_details.append(f"EC2 Instance: {instance['InstanceId']}")
                                    safe_to_delete = False
                                    print(
                                        f"Image {image_tags} is currently running in EC2 instance {instance['InstanceId']}.")

                    ecr_images.append({
                        'region': region,
                        'repository': repo_name,
                        'tags': image_tags,
                        'last_updated': last_updated,
                        'last_used': last_used,
                        'tags_in_use': ', '.join(tags_in_use),
                        'usage_details': '; '.join(usage_details),
                        'untagged_count': untagged_count,
                        'image_count': image_count,
                        **tag_values
                    })

                if image_count == 0:
                    ecr_images.append({
                        'region': region,
                        'repository': repo_name,
                        'tags': [],
                        'last_updated': 'N/A',
                        'last_used': 'N/A',
                        'tags_in_use': '',
                        'usage_details': '',
                        'untagged_count': untagged_count,
                        'image_count': image_count,
                        **{key: 'N/A' for key in tag_keys}
                    })

        except botocore.exceptions.ClientError as error:
            print(f"An error occurred: {error}")
            continue

    return ecr_images


def save_to_csv(data, filename='ecr_gift_svs.csv'):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        headers = ['Region', 'Repository', 'Number of Images', 'Tag', 'Used Date', 'Last Updated',
                   'Tags Currently In Use', 'Where It Is Used', 'Untagged Image Count'] + tag_keys
        writer.writerow(headers)
        for image in data:
            row = [
                image['region'],
                image['repository'],
                image['image_count'],
                ', '.join(image['tags']),
                image['last_used'].strftime('%Y-%m-%d %H:%M:%S') if isinstance(image['last_used'], datetime) else 'N/A',
                image['last_updated'].strftime('%Y-%m-%d %H:%M:%S') if isinstance(image['last_updated'],
                                                                                  datetime) else 'N/A',
                image['tags_in_use'],
                image['usage_details'],
                image['untagged_count'],
            ]
            for key in tag_keys:
                row.append(image.get(key, 'N/A'))
            writer.writerow(row)
    print(f"Data saved to {filename}.")


if __name__ == "__main__":
    # Get ECR images usage data
    images_usage = get_ecr_images_usage()

    # Save the data to a CSV file
    save_to_csv(images_usage, 'ecr_gift_svs.csv')
    print("Report saved to ecr_gift_svs.csv")
