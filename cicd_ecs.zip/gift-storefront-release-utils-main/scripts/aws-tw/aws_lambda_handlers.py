import csv
import boto3
from datetime import datetime, timezone

### TW SVS

### DEV WGIFT

### PROD GIFT SOLUTIONS

AWS_REGIONS = ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'eu-west-1']

CUSTOM_TAGS = ['fiserv::apm', 'fiserv::app', 'fiserv::owner', 'fiserv::description', 'fiserv::environment',
               'fiserv::stage', 'fiserv::artifact', 'fiserv::version', 'fiserv::notes']


def get_lambda_details(client, logs_client):
    lambda_functions = []

    paginator = client.get_paginator('list_functions')
    for page in paginator.paginate():
        for function in page['Functions']:
            try:
                # Get Lambda function details with default values for missing keys
                function_name = function.get('FunctionName', '')
                arn = function.get('FunctionArn', '')
                runtime = function.get('Runtime', '')
                environment = function.get('Environment', {}).get('Variables', {})
                last_modified = function.get('LastModified', '')
                description = function.get('Description', '')
                layers = [layer['Arn'] for layer in function.get('Layers', [])]

                # Get Lambda function tags
                response = client.list_tags(Resource=arn)
                tags = response.get('Tags', {})

                # Get specific tag values
                specific_tag_values = {tag: tags.get(tag, '') for tag in CUSTOM_TAGS}

                # Search for the log group containing the function name
                log_group_name = None
                log_group_paginator = logs_client.get_paginator('describe_log_groups')
                for log_group_page in log_group_paginator.paginate(logGroupNamePrefix=f'/aws/lambda/{function_name}'):
                    for log_group in log_group_page['logGroups']:
                        if function_name in log_group['logGroupName']:
                            log_group_name = log_group['logGroupName']
                            break
                    if log_group_name:
                        break

                # Get the last invocation date from CloudWatch Logs if log group is found
                if log_group_name:
                    try:
                        log_streams = logs_client.describe_log_streams(
                            logGroupName=log_group_name,
                            orderBy='LastEventTime',
                            descending=True,
                            limit=1
                        )
                        if log_streams['logStreams']:
                            last_invoked = log_streams['logStreams'][0]['lastEventTimestamp']
                            last_invoked_date = datetime.fromtimestamp(last_invoked / 1000, tz=timezone.utc)
                            now = datetime.now(timezone.utc)
                            days_since_last_invoked = (now - last_invoked_date).days
                            last_invoked_date_str = last_invoked_date.strftime('%Y-%m-%d')
                            if days_since_last_invoked < 1:
                                days_since_last_invoked_str = '0'
                            else:
                                days_since_last_invoked_str = str(days_since_last_invoked)
                        else:
                            last_invoked_date_str = 'Never'
                            days_since_last_invoked_str = 'Never'
                    except logs_client.exceptions.ResourceNotFoundException:
                        last_invoked_date_str = 'Never'
                        days_since_last_invoked_str = 'Never'
                else:
                    last_invoked_date_str = 'Never'
                    days_since_last_invoked_str = 'Never'

                # Append the details to the list
                lambda_function = {
                    'FunctionName': function_name,
                    'Description': description,
                    'Runtime': runtime,
                    'Region': client.meta.region_name,
                    'LastInvokedDate': last_invoked_date_str,
                    'DaysSinceLastInvoked': days_since_last_invoked_str,
                    'FunctionArn': arn,
                    'Layers': layers,
                    'Environment': environment,
                    'LastModified': last_modified,
                    'Tags': tags
                }
                lambda_function.update(specific_tag_values)
                lambda_functions.append(lambda_function)
            except Exception as e:
                print(f"Error processing function {function.get('FunctionName', '')}: {e}")

    return lambda_functions


def list_all_lambdas_to_csv(file_name):
    lambda_functions = []

    for region in AWS_REGIONS:
        try:
            # Create a Boto3 client for Lambda in the specified region
            client = boto3.client('lambda',
                                  region_name=region,
                                  aws_access_key_id=AWS_ACCESS_KEY_ID,
                                  aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
                                  aws_session_token=AWS_SESSION_TOKEN)

            # Create a Boto3 client for CloudWatch Logs in the specified region
            logs_client = boto3.client('logs',
                                       region_name=region,
                                       aws_access_key_id=AWS_ACCESS_KEY_ID,
                                       aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
                                       aws_session_token=AWS_SESSION_TOKEN)

            region_lambda_details = get_lambda_details(client, logs_client)
            lambda_functions.extend(region_lambda_details)
        except Exception as e:
            print(f"Error processing region {region}: {e}")

    # Write the details to a CSV file
    try:
        with open(file_name, 'w', newline='') as csvfile:
            fieldnames = [
                             'FunctionName', 'Description', 'Runtime', 'Region',
                             'LastInvokedDate', 'DaysSinceLastInvoked', 'FunctionArn',
                             'Layers', 'Environment', 'LastModified', 'Tags'
                         ] + CUSTOM_TAGS
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writeheader()
            for function in lambda_functions:
                row = {key: (value if value else '') for key, value in function.items()}
                # Convert the environment and tags dictionaries to strings
                row['Environment'] = str(row['Environment'])
                row['Tags'] = str(row['Tags'])
                row['Layers'] = str(row['Layers'])
                writer.writerow(row)

        print(f"CSV file '{file_name}' created successfully.")
    except Exception as e:
        print(f"Error writing to CSV file: {e}")


def main():
    # Create CSV of Lambda functions
    list_all_lambdas_to_csv('gift-prod.csv')


if __name__ == "__main__":
    main()
