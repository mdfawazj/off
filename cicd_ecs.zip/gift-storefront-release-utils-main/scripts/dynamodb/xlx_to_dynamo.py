import argparse
import json
import logging
import os
import pandas as pd

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def excel_to_dynamodb(input_excel_path, output_dir=None):
    try:
        # Set output directory to the same directory as the input file if not provided
        if output_dir is None:
            output_dir = os.path.dirname(input_excel_path)

        # Read the Excel file
        excel_data = pd.read_excel(input_excel_path, sheet_name=None)

        for sheet_name, data in excel_data.items():
            items = []
            for _, row in data.iterrows():
                # Skip columns with no data
                dynamodb_item = {
                    'PutRequest': {
                        'Item': {
                            column: {'S': str(value)} for column, value in row.items() if pd.notna(value)
                        }
                    }
                }
                items.append(dynamodb_item)

            output_json_path = os.path.join(output_dir, f"{sheet_name}.json")
            with open(output_json_path, 'w') as json_file:
                json.dump(items, json_file)

            logging.info(
                f"Successfully converted sheet '{sheet_name}' to DynamoDB JSON format and saved to {output_json_path}")
    except Exception as e:
        logging.error(f"Error converting Excel to DynamoDB JSON: {e}")


def main():
    parser = argparse.ArgumentParser(description='Convert Excel to DynamoDB JSON Format')
    parser.add_argument('--input-excel', required=True, help='Path to the input Excel file')
    parser.add_argument('--output-dir', help='Directory to save the output JSON files (optional)')

    args = parser.parse_args()

    excel_to_dynamodb(args.input_excel, args.output_dir)


if __name__ == '__main__':
    main()
