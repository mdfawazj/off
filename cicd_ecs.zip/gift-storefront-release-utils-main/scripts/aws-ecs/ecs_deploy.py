import boto3
import os
import argparse
import logging
import sys
import time


def setup_logging():
    logger = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


def assume_role():
    sts_client = boto3.client('sts')
    try:
        response = sts_client.assume_role(
            RoleArn=os.getenv('GIFT_ROLE_ARN'),
            RoleSessionName="GitLabCISession",
            ExternalId=os.getenv('STS_GIFT_EXTERNAL_ID')
        )
        return response['Credentials']
    except Exception as e:
        logger.error(f"Failed to assume role: {e}")
        sys.exit(1)


def get_boto3_client(service, credentials):
    return boto3.client(
        service,
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken']
    )


def get_existing_task_definition(client, task_family):
    try:
        response = client.describe_task_definition(taskDefinition=task_family)
        return response['taskDefinition']
    except Exception as e:
        logger.error(f"Failed to get existing task definition: {e}")
        sys.exit(1)


def update_task_definition(task_definition, image):
    try:
        task_definition['containerDefinitions'][0]['image'] = image
        # Remove read-only fields
        for key in ['taskDefinitionArn', 'revision', 'status', 'requiresAttributes', 'registeredAt', 'registeredBy']:
            task_definition.pop(key, None)
        logger.debug(f"Updated task Definition: {task_definition}")
        return task_definition
    except Exception as e:
        logger.error(f"Failed to update task definition: {e}")
        sys.exit(1)


def register_new_task_definition(client, task_definition):
    try:
        response = client.register_task_definition(
            family=task_definition['family'],
            taskRoleArn=task_definition.get('taskRoleArn'),
            executionRoleArn=task_definition.get('executionRoleArn'),
            networkMode=task_definition.get('networkMode'),
            containerDefinitions=task_definition['containerDefinitions'],
            volumes=task_definition.get('volumes', []),
            placementConstraints=task_definition.get('placementConstraints', []),
            requiresCompatibilities=task_definition.get('requiresCompatibilities', []),
            cpu=task_definition.get('cpu'),
            memory=task_definition.get('memory'),
            runtimePlatform=task_definition.get('runtimePlatform'),
        )
        return response['taskDefinition']['taskDefinitionArn']
    except Exception as e:
        logger.error(f"Failed to register new task definition: {e}")
        sys.exit(1)


def update_ecs_service(client, cluster, service, task_definition_arn):
    try:
        response = client.update_service(
            cluster=cluster,
            service=service,
            taskDefinition=task_definition_arn
        )
        return response
    except Exception as e:
        logger.error(f"Failed to update ECS service: {e}")
        sys.exit(1)


def wait_for_service_update(client, cluster, service, new_task_definition_arn, previous_task_definition_arn):
    while True:
        response = client.describe_services(cluster=cluster, services=[service])
        deployments = response['services'][0]['deployments']
        primary_deployment = next((d for d in deployments if d['status'] == 'PRIMARY'), None)

        if primary_deployment:
            if primary_deployment['rolloutState'] == 'COMPLETED':
                if primary_deployment['taskDefinition'] == new_task_definition_arn:
                    logger.info("ECS service updated successfully with new task version")
                    return True
                elif primary_deployment['taskDefinition'] == previous_task_definition_arn:
                    logger.error("ECS service update failed and rolled back to previous running task version")
                    return False
            elif primary_deployment['rolloutState'] == 'FAILED':
                logger.error("ECS Service update Failed")
                return False

        logger.info("Waiting for ECS service to update - will check back in 30 secs")
        time.sleep(30)


if __name__ == "__main__":
    logger = setup_logging()

    parser = argparse.ArgumentParser()
    parser.add_argument('--image-repo', required=True, help='Docker image repository')
    parser.add_argument('--image-tag', required=True, help='Docker image tag')
    args = parser.parse_args()

    task_family = os.getenv('TASK_FAMILY')
    if not task_family:
        logger.error("TASK_FAMILY environment variable is not set")
        sys.exit(1)

    cluster_name = os.getenv('ECS_CLUSTER_NAME')
    if not cluster_name:
        logger.error("ECS_CLUSTER_NAME environment variable is not set")
        sys.exit(1)

    service_name = os.getenv('ECS_SERVICE_NAME')
    if not service_name:
        logger.error("ECS_SERVICE_NAME environment variable is not set")
        sys.exit(1)

    new_image = f"{args.image_repo}:{args.image_tag}"
    logger.info(f"Updating ECS with image: {new_image}")

    credentials = assume_role()
    client = get_boto3_client('ecs', credentials)

    existing_task_definition = get_existing_task_definition(client, task_family)
    previous_task_definition_arn = existing_task_definition['taskDefinitionArn']

    updated_task_definition = update_task_definition(existing_task_definition, new_image)
    new_task_definition_arn = register_new_task_definition(client, updated_task_definition)
    update_ecs_service(client, cluster_name, service_name, new_task_definition_arn)

    success = wait_for_service_update(client, cluster_name, service_name, new_task_definition_arn, previous_task_definition_arn)
    if not success:
        logger.error("Deployment Failed. Please Check ECS Logs.")
        sys.exit(1)