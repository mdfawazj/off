#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Path to the gradle.properties file
GRADLE_PROPERTIES_FILE="gradle.properties"

# Function to increment the version number
increment_version() {
  local version=$1
  local delimiter=.
  local array=($(echo "$version" | tr $delimiter '\n'))

  # Increment the patch version
  local new_version="${array[0]}.$((${array[1]}+1)).0-Release"
  echo "$new_version"
}

# Read the current version from the gradle.properties file
current_version=$(grep "^ReleaseVersion=" $GRADLE_PROPERTIES_FILE | cut -d'=' -f2)
echo "Current version: $current_version"

# Increment the version
new_version=$(increment_version $current_version)
echo "New version: $new_version"

# Update the gradle.properties file with the new version
sed -i "s/^ReleaseVersion=.*/ReleaseVersion=$new_version/" $GRADLE_PROPERTIES_FILE

echo "Version updated in $GRADLE_PROPERTIES_FILE to $new_version"
