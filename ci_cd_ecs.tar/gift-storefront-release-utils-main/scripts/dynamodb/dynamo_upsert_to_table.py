import argparse
import json
import boto3
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def bulk_upsert_dynamodb_from_file(input_file_path, env, table_name, aws_access_key_id, aws_secret_access_key,
                                   aws_session_token):
    try:
        session = boto3.Session(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token
        )
        dynamodb = session.client('dynamodb')
        table_name = f"{env}{table_name}"
        with open(input_file_path, 'r') as json_file:
            items = json.load(json_file)

        for i in range(0, len(items), 25):
            batch = items[i:i + 25]
            request_items = {table_name: batch}
            response = dynamodb.batch_write_item(RequestItems=request_items)
            unprocessed_items = response.get('UnprocessedItems', {})

            while unprocessed_items:
                response = dynamodb.batch_write_item(RequestItems=unprocessed_items)
                unprocessed_items = response.get('UnprocessedItems', {})

            logging.info(f"Batch {i // 25 + 1} upserted successfully.")
    except Exception as e:
        logging.error(f"Error during bulk upsert to DynamoDB: {e}")


def main():
    parser = argparse.ArgumentParser(description='Bulk Upsert to DynamoDB from JSON File with AWS Credentials')
    parser.add_argument('--input-json', required=True, help='Path to the input JSON file containing DynamoDB items')
    parser.add_argument('--env', required=True, help='Environment name prefix(e.g., dev, qa, etc.)')
    parser.add_argument('--tableName', required=True,
                        help='Dynamo Table name (e.g., Application_proprties, Storeconf, etc.)')
    parser.add_argument('--aws-access-key-id', required=True, help='AWS Access Key ID')
    parser.add_argument('--aws-secret-access-key', required=True, help='AWS Secret Access Key')
    parser.add_argument('--aws-session-token', required=False, help='AWS Session Token (optional)')

    args = parser.parse_args()

    env_uppercase = args.env.upper()
    table_name_uppercase = args.tableName.upper()

    bulk_upsert_dynamodb_from_file(
        args.input_json,
        env_uppercase,
        table_name_uppercase,
        args.aws_access_key_id,
        args.aws_secret_access_key,
        args.aws_session_token
    )


if __name__ == '__main__':
    main()
