import argparse
import csv
import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def csv_to_dynamodb(input_csv_path, output_json_path):
    try:
        items = []
        with open(input_csv_path, mode='r') as csv_file:
            csv_reader = csv.DictReader(csv_file)
            for row in csv_reader:
                # Skip columns with no data
                dynamodb_item = {
                    'PutRequest': {
                        'Item': {
                            column: {'S': str(value)} for column, value in row.items() if value
                        }
                    }
                }
                items.append(dynamodb_item)

        with open(output_json_path, 'w') as json_file:
            json.dump(items, json_file)

        logging.info(f"Successfully converted {input_csv_path} to DynamoDB JSON format and saved to {output_json_path}")
    except Exception as e:
        logging.error(f"Error converting CSV to DynamoDB JSON: {e}")


def main():
    parser = argparse.ArgumentParser(description='Convert CSV to DynamoDB JSON Format')
    parser.add_argument('--input-csv', required=True, help='Path to the input CSV file')
    parser.add_argument('--output-json', required=True, help='Path to the output JSON file')

    args = parser.parse_args()

    csv_to_dynamodb(args.input_csv, args.output_json)


if __name__ == '__main__':
    main()