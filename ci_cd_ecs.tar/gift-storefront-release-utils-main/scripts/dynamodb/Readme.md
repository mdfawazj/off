## CSV TO DYNAMO JSON:

    python3 csv_to_dynamodb.py --input-csv <path_to_input_csv> --output-json <path_to_output_json>

### Description:

    This script converts a CSV file to a JSON file formatted for DynamoDB bulk upsert operations.
    Each row in the CSV file is converted into a DynamoDB item format, with columns as attributes.
    Empty or null values in the CSV are skipped and not included in the output JSON.

### Parameters:

 - --input-csv: The path to the input CSV file that you want to convert.
 - --output-json: The path where the output JSON file will be saved.

### Example:

    python3 csv_to_dynamodb.py --input-csv input-props.csv --output-json output-props.json

    This command reads the CSV file input-props.csv, converts it to DynamoDB JSON format,
    and saves the result to output-props.json on the same folder.


## DYNAMO UPSERT TO TABLE:

    python3 dynamo_upsert_to_table.py --input-json <path_to_input_json> --env <environment> --aws-access-key-id <access_key> --aws-secret-access-key <secret_key> [--aws-session-token <session_token>]

### Description:

    This script performs a bulk upsert operation to DynamoDB APPLICATION PROPERTIES Table using items from a specified JSON file.
    The JSON file should contain items in the format expected by DynamoDB(Refer to CSV TO DYNAMO JSON). The script supports batching
    of items to comply with DynamoDB's batch operation limits(25). It automatically retries unprocessed items.

### Parameters:

 - --input-json: The path to the input JSON file containing DynamoDB items.
 - --env: The environment name (e.g., dev, qa, etc.).
 - --aws-access-key-id: Your AWS Access Key ID.
 - --aws-secret-access-key: Your AWS Secret Access Key.
 - --aws-session-token: Your AWS Session Token, if using temporary credentials.

### Example:

    python3 dynamo_upsert_to_table.py --input-json output-props.json --env dev --aws-access-key-id EXAMPLE --aws-secret-access-key EXAMPLEKEY --aws-session-token EXAMPLETOKEN

    This command reads the items from output-props.json and performs a bulk upsert operation into the DynamoDB table
    named "DEV_APPLICATION_PROPERTIES" using the provided AWS credentials.