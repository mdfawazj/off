#! /bin/bash

# smtp email attributes
SMTP_URL="smtp://usomausrsmtp.1dc.com:25"
SMTP_FROM=$1
SMTP_TO=$2
SMTP_CC=$3
MAIL_FILE=$PWD/mail-data.txt

# Scan Variables
FISERV_ISSUES_FILTER_SET="a243b195-0a59-3f8b-1403-d55b7a7d78e6"
CODE_QUALITY_ISSUES_FILTER_SET="5ef8392c-8f16-4e1a-9b9c-d057468a3f95"

TOKEN_JSON_RESPONSE=$PWD/auth/token-auth.json
COOKIE_FILE=$PWD/auth/cookies-auth.json

FORTIFY_BASE_URL="https://fortify.fiserv.one/ssc"

getVulnerabilitySet() {
  COOKIE_FILE=$1
  AUTH_TOKEN=$2
  FISERV_ISSUES_FILTER_SET=$3
  CODE_QUALITY_ISSUES_FILTER_SET=$4

  mkdir -p $PWD/token
  AUTH_JSON_FILTER_RESPONSE=$PWD/token/auth-issue-set$(date +%s).json
  AUTH_DAST_RESPONSE=$PWD/token/auth-dast-set$(date +%s).json
  AUTH_JSON_COMBINED_RESPONSE=$PWD/token/auth-combined-set$(date +%s).json

  curl --cookie "${COOKIE_FILE}" -s -D - "${FORTIFY_BASE_URL}/api/v1/projectVersions/${SSC_PROJECT_VERSION_ID}/issues?start=0&limit=100&orderby=friority&filterset=${FISERV_ISSUES_FILTER_SET}&showhidden=false&showremoved=false&showsuppressed=false&showshortfilenames=true" -H "Authorization: Bearer ${AUTH_TOKEN}" -o "${AUTH_JSON_FILTER_RESPONSE}"
  curl --cookie "${COOKIE_FILE}" -s -D - "${FORTIFY_BASE_URL}/api/v1/projectVersions/${SSC_PROJECT_DAST_VERSION_ID}/issues?start=0&limit=100&orderby=friority&filterset=${FISERV_ISSUES_FILTER_SET}&showhidden=false&showremoved=false&showsuppressed=false&showshortfilenames=true" -H "Authorization: Bearer ${AUTH_TOKEN}" -o "${AUTH_DAST_RESPONSE}"
  RC_ISSUES_API=$?
  if [ $RC_ISSUES_API -eq 0 ]
  then
#    jq -s '{
#        "data": (.[0].data + .[1].data)
#    }' "$AUTH_JSON_FILTER_RESPONSE" "$AUTH_JSON_CODE_RESPONSE" > "$AUTH_JSON_COMBINED_RESPONSE"
    parseAuditIssues ${AUTH_JSON_FILTER_RESPONSE} ${AUTH_DAST_RESPONSE}
  else
   echo "failed to retrieve issues"
   exit $RC_AUDITAPI
  fi
}

parseAuditIssues() {
    declare -gA VULN_MAP
    response=$1
    dast_response=$2

    SONATYPE_CRITICAL=$(jq -r '[.data[] | select(.friority == "Critical") | select(.engineType == "SONATYPE" )] | length' ${response})
    SONATYPE_HIGH=$(jq -r '[.data[] | select(.friority == "High") | select(.engineType == "SONATYPE" )] | length' ${response})
    SONATYPE_MEDIUM=$(jq -r '[.data[] | select(.friority == "Medium") | select(.engineType == "SONATYPE" )] | length' ${response})
    SONATYPE_LOW=$(jq -r '[.data[] | select(.friority == "Low") | select(.engineType == "SONATYPE" )] | length' ${response})

    SCA_CRITICAL=$(jq -r '[.data[] | select(.friority == "Critical") | select(.engineType == "SCA" )] | length' ${response})
    SCA_HIGH=$(jq -r '[.data[] | select(.friority == "High") | select(.engineType == "SCA" )] | length' ${response})
    SCA_MEDIUM=$(jq -r '[.data[] | select(.friority == "Medium") | select(.engineType == "SCA" )] | length' ${response})
    SCA_LOW=$(jq -r '[.data[] | select(.friority == "Low") | select(.engineType == "SCA" )] | length' ${response})

    WebInspect_CRITICAL=$(jq -r '[.data[] | select(.friority == "Critical") | select(.engineType == "WEBINSPECT" )] | length' ${dast_response})
    WebInspect_HIGH=$(jq -r '[.data[] | select(.friority == "High") | select(.engineType == "WEBINSPECT" )] | length' ${dast_response})
    WebInspect_MEDIUM=$(jq -r '[.data[] | select(.friority == "Medium") | select(.engineType == "WEBINSPECT" )] | length' ${dast_response})
    WebInspect_LOW=$(jq -r '[.data[] | select(.friority == "Low") | select(.engineType == "WEBINSPECT" )] | length' ${dast_response})

    TOTAL_CRITICAL=$((SONATYPE_CRITICAL + SCA_CRITICAL + WebInspect_CRITICAL))
    TOTAL_HIGH=$((SONATYPE_HIGH + SCA_HIGH + WebInspect_HIGH))
    TOTAL_MEDIUM=$((SONATYPE_MEDIUM + SCA_MEDIUM + WebInspect_MEDIUM))
    TOTAL_LOW=$((SONATYPE_LOW + SCA_LOW + WebInspect_LOW))

    VULN_MAP=([SONATYPE_CRITICAL]="${SONATYPE_CRITICAL}" [SONATYPE_HIGH]="${SONATYPE_HIGH}" [SONATYPE_MEDIUM]="${SONATYPE_MEDIUM}" [SONATYPE_LOW]="${SONATYPE_LOW}" [SCA_CRITICAL]="${SCA_CRITICAL}" [SCA_HIGH]="${SCA_HIGH}" [SCA_MEDIUM]="${SCA_MEDIUM}" [SCA_LOW]="${SCA_LOW}" [WebInspect_CRITICAL]="${WebInspect_CRITICAL}" [WebInspect_HIGH]="${WebInspect_HIGH}" [WebInspect_MEDIUM]="${WebInspect_MEDIUM}" [WebInspect_LOW]="${WebInspect_LOW}" [TOTAL_CRITICAL]="${TOTAL_CRITICAL}" [TOTAL_HIGH]="${TOTAL_HIGH}" [TOTAL_MEDIUM]="${TOTAL_MEDIUM}" [TOTAL_LOW]="${TOTAL_LOW}")
}

formMessageBody() {
  # html message to send
  messageBody=$(eval "echo \"$(<buildbreaker_email_template.html)\"")

  # curl smtp attrs
  mail_from="Gift Solutions USF Dev <$SMTP_FROM>"
  mail_to="<$SMTP_TO>"
  mail_cc="<$SMTP_CC>"
  mail_subject="Vulnerability Scan Summary - Gift Solutions Storefront"

  message_base64=$(echo "${messageBody}" | base64)

  echo "From: $mail_from
To: $mail_to
Subject: $mail_subject
Reply-To: $mail_reply_to
Cc: $mail_cc
MIME-Version: 1.0
Content-Type: text/html; charset=utf-8
Content-Transfer-Encoding: base64

$message_base64" > $MAIL_FILE

}

sendSummaryEmail() {
  # sending email
  echo "sending email..."
  curl -s "$SMTP_URL" \
       --mail-from "$SMTP_FROM" \
       --mail-rcpt "$SMTP_TO" \
       $(echo "$SMTP_CC" | sed 's/,/ /g' | xargs -n1 echo --mail-rcpt) \
       -T "$MAIL_FILE" --verbose
  RC=$?
  if [ $RC -eq 0 ]
  then
      echo "Email send success"
  else
      echo "Email send failed"
  fi
}

runScript() {
    echo "Running Script"
    AUTH_TOKEN=$(cat ${TOKEN_JSON_RESPONSE} | jq .data.token)
    TOKEN_ID=$(cat ${TOKEN_JSON_RESPONSE} | jq .data.id)
    #GET Vulnerabilities count
    getVulnerabilitySet ${COOKIE_FILE} ${AUTH_TOKEN} ${FISERV_ISSUES_FILTER_SET} ${CODE_QUALITY_ISSUES_FILTER_SET}
    #HTML Template
    formMessageBody
    #Email
  	sendSummaryEmail
    #Remove Token
    curl -X DELETE "${FORTIFY_BASE_URL}/api/v1/tokens/${TOKEN_ID}" -H "Authorization: Basic ${FORTIFY_AUTH_TOKEN}" -H "accept: application/json"
}

getToken(){
  mkdir -p $PWD/auth
  curl -s -D - -X POST "${FORTIFY_BASE_URL}/api/v1/tokens" -H "Authorization: Basic ${FORTIFY_AUTH_TOKEN}" -H 'Cache-Control: no-cache' -H 'Content-Type: application/json' -d '{"type": "UnifiedLoginToken"}' -o "${TOKEN_JSON_RESPONSE}" -c "${COOKIE_FILE}"
  RC_TOKEN_API=$?
}

# SCRIPT START
echo "Fetching Token"
getToken
if [ $? -eq 0 ]
then
  echo "Running Script"
  runScript
else
  echo "failed to retrieve token"
  exit $?
fi